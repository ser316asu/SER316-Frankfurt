package net.sf.memoranda.date;

/*$Id: DateListener.java,v 1.2 2004/01/30 12:17:41 alexeya Exp $*/
public interface DateListener {

  void dateChange(CalendarDate date);

}